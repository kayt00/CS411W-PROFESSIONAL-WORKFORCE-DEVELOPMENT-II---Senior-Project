//
//  SSHServerEditPasswsordViewModel.swift
//  BlackBear
//
//  Created by ktayl023 on 3/5/21.
//

import Combine

final class SSHServerEditPasswordViewModel: ObservableObject, Identifiable {
    var networkService: NetworkService?

    func setup(_ networkService: NetworkService) {
        self.networkService = networkService
    }

    func updateSSHPassword(currentPassword: String, newPassword: String, newPasswordReentry: String) {
        if(currentPassword == networkService?.ssh.sshHashPassword && newPassword == newPasswordReentry) {
            networkService?.ssh.sshHashPassword = newPassword
        } else if(currentPassword != networkService?.ssh.sshHashPassword) {
            print("Password Invalid") //TO DO: alert
        }
        else if(newPassword != newPasswordReentry) {
            print("Passwords Do Not Match") //TO DO: alert
        }
    }
}

