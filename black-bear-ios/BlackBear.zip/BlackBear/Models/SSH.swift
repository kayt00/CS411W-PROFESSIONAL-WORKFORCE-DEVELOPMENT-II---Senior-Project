//
//  SSH.swift
//  BlackBear
//
//  Created by ktayl023 on 2/9/21.
//

import Foundation

#warning("TODO: Remove hardcoded default values")
struct SSH: Identifiable {
    var id = UUID()
    var username: String = "harrythespy"
    var sshHashPassword: String = "gdhdjhwfre"
    var ip: String = "192.168.1.5"

}
