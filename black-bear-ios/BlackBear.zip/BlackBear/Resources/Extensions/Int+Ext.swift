//
//  Int+Ext.swift
//  BlackBear
//
//  Created by Jeremy Fleshman on 4/13/21.
//

import Foundation

extension Int {
    var boolValue: Bool { return self != 0 }
}
